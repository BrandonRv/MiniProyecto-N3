<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    require("connection.php");

    // Obtener los datos del formulario
    $photo = $_FILES["newFoto"] ?? null;
    $name = $_POST["newNombre"];
    $bio = $_POST["newBio"];
    $phone = $_POST["newTelef"];
    $email = $_POST["newEmail"];
    $password = $_POST["newPassw"];
    $user_id = $_SESSION["user_id"];
    $email = $_SESSION["dato_email"];
    //$current_email = $_SESSION["dato_email"];

    // Validar la foto
    if ($photo) {
        // Comprobar si el archivo es una imagen válida
        $image_info = getimagesize($photo["tmp_name"]);
        if ($image_info === false) {
            $_SESSION["error_nophoto"] = "El archivo no es una imagen válida";
            redirect("update_data.php");
        }
        // Leer el contenido de la imagen
        $photo_content = file_get_contents($photo["tmp_name"]);
    } else {
        // No se ha subido ninguna foto
        $photo_content = "";
        $_SESSION["error_nophoto"] = "Agregue una Foto";
        redirect("update_data.php");
    }

    // Encriptar la contraseña
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Usar el bloque try...catch para manejar las excepciones
    try {
        // Preparar la consulta para comprobar si el email ya existe
        $stmt_check = $mysqli->prepare("SELECT * FROM usuarios WHERE email = ? AND NOT id = ?");
        $stmt_check->bind_param("si", $email, $user_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $num_rows = $result_check->num_rows;
        $stmt_check->close();

        // Si el email ya existe, mostrar un mensaje de error y redirigir al usuario
        if ($num_rows > 0) {
            $_SESSION["error_update"] = "Este Email ya Existe!";
            redirect("update_data.php");
        }

        // Preparar la consulta para actualizar los datos del usuario
        $stmt_update = $mysqli->prepare("UPDATE usuarios SET foto = ?, nombre = ?, bio = ?, telefono = ?, email = ?, password = ? WHERE id = ?");
        // Escapar el contenido de la imagen
       // $escaped_photo = $mysqli->real_escape_string($photo_content);
        $stmt_update->bind_param("ssssssi", $photo_content, $name, $bio, $phone, $email, $hashed_password, $user_id);
        $stmt_update->execute();
        $stmt_update->close();

        // Redirigir al usuario a la página de autenticación
        redirect("autenticacion.php");
    } catch (mysqli_sql_exception $e) {
        // Mostrar el mensaje de error de la excepción
        echo "Error: " . $e->getMessage();
    }
}

// Función para redirigir al usuario a otra página
function redirect($url) {
    header("Location: $url");
    die();
}
